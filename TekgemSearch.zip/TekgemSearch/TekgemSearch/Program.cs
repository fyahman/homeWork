﻿using System;

namespace TekgemSearch
{
    class Program
    {
        static void Main(string[] args)
		{
			string input = string.Empty;
			bool running = true;
           
			Console.WriteLine("Please enter city:");

			while (running)
			{


				char nextChar = Console.ReadKey().KeyChar;
				if (nextChar == '0')
				{
					running = false;
				}

				else
				{
					int i = 0;
					input += Char.ToUpper(nextChar);

					CityFinder finder = new CityFinder();
					ICityResult finalResults = finder.Search(input);
				
					Console.WriteLine($"\nSearching: {input}" );
					Console.WriteLine($"\nCities available:");

					foreach (var city in finalResults.NextCities)
					{
						Console.WriteLine($"{i}. \'{city}\'");

						i++;
					}
					Console.WriteLine($"\nNext letters available:");
					foreach (var character in finalResults.NextLetters)
					{
						Console.WriteLine($"\'{character}\'");
					}

					Console.WriteLine("\nPRESS 0 to EXIT");
                    Console.WriteLine(new string('-',40));
				}
			}
		}
	}
}
