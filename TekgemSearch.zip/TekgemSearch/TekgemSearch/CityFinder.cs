﻿using System;
using System.Collections.Generic;

namespace TekgemSearch
{
    public class CityFinder : ICityFinder
    {
		string[] testCities ={
			"BANDUNG",
			"BANGUI",
			"BANGKOK",
			"BANGALORE",	
			"LA PAZ",
			"LA PLATA",
			"LAGOS",
			"LEEDS",
			"ZARIA",
			"ZHUGHAI",
			"ZIBO"
		};

		HashSet<string> cities;

		public CityFinder()
		{
			
			cities = new HashSet<string>(testCities);
		}


		public ICityResult Search(string searchString)
		{
			
		
			int nextLetterIndex = searchString.Length;
			ICityResult results = new CityResult();

			foreach (string cityName in cities)
			{
				
				if (cityName.StartsWith(searchString))
				{
					
					results.NextCities.Add(cityName);
					results.NextLetters.Add(cityName[nextLetterIndex].ToString());
				}
			}

			return results;
		}
	}
}
