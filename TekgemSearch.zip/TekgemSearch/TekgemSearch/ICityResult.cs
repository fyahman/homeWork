﻿using System;
using System.Collections.Generic;

namespace TekgemSearch
{
    public interface ICityResult
    {
        ICollection<string> NextLetters { get; set; }

        ICollection<string> NextCities { get; set; }

    }
}
