﻿using System;
namespace TekgemSearch
{

    public interface ICityFinder 
    {

        ICityResult Search(string searchString);
    }

    
}
